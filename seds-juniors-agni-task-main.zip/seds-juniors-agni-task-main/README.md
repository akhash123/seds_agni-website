# SEDS Juniors Astronight 2021 - Task
#### By SEDS Agni

## Important 

Template is in **agni_task/task_page.html** location

Create a seperate CSS / JS files for each task in **assets/(js/css)** directory 

**Ideally use VS Code with LiveServer to overcome relative path issues**

**DO NOT EDIT ANY OTHER FILES IN "assets" !!** 
