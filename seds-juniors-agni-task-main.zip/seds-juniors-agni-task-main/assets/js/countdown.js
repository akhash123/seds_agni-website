//Countdown Timer 
var finishingTime = 1606498200000;
var now = new Date().getTime();
var distance = finishingTime - now;

  // Time calculations for days, hours, minutes and seconds
 // var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  if(hours <= 0) {
    if(minutes <= 0) {
        document.getElementById('timer').innerHTML = 'TIME UP!!!';
    }else {
        if(minutes == 1)
        document.getElementById('timer').innerHTML = "Time Remaining : "+ minutes + " minute";
        else 
        document.getElementById('timer').innerHTML = "Time Remaining : "+ minutes + " minutes";
    }
    
  }else {
    if(hours == 1)
        document.getElementById('timer').innerHTML = "Time Remaining : "+ hours + " hour " + minutes + " minutes";
    else
        document.getElementById('timer').innerHTML = "Time Remaining : "+ hours + " hours " + minutes + " minutes";

  }



// Update the count down every 1 minute
var x = setInterval(function() {

  // Get today's date and time
  now = new Date().getTime();
  // Find the distance between now and the count down date
  var distance = finishingTime - now;
  // Time calculations for hours and minutes
  var hours = Math.floor((distance) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));    
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("timer").innerHTML = "EXPIRED";
  }

  if(hours <= 0) {
    if(minutes <= 0) {
        document.getElementById('timer').innerHTML = 'TIME UP!!!';
    }else {
        if(minutes == 1)
        document.getElementById('timer').innerHTML = "Time Remaining : "+ minutes + " minute";
        else 
        document.getElementById('timer').innerHTML = "Time Remaining : "+ minutes + " minutes";
    }
    
  }else {
    if(hours == 1)
        document.getElementById('timer').innerHTML = "Time Remaining : "+ hours + " hour " + minutes + " minutes";
    else
        document.getElementById('timer').innerHTML = "Time Remaining : "+ hours + " hours " + minutes + " minutes";

  }

}, 60000);