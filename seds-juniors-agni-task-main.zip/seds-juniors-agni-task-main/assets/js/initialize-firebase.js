const firebaseConfig = {
  apiKey: "AIzaSyBKP31PNB3_xlhCbMbdEdPPhfywCxMVDYw",
  authDomain: "seds-junior-quiz.firebaseapp.com",
  databaseURL: "https://seds-junior-quiz.firebaseio.com",
  projectId: "seds-junior-quiz",
  storageBucket: "seds-junior-quiz.appspot.com",
  messagingSenderId: "192293299202",
  appId: "1:192293299202:web:a485d0263499693016b31b",
  measurementId: "G-056PXKB8CQ"
};
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();